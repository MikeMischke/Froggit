//ДЗ: СДЕЛАТЬ ТАК, ЧТОБЫ ПРИ ПОВОРОТЕ ЭКРАНА СЧЁТЧИК НЕ ОБНУЛЯЛСЯ
package com.example.myhomework_1_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Создание полей для вывода на экран нужных значений
    private TextView textCount; // окно вывода значения счётчик
    private Button button; // кнопка счётчика
    private int count = 0; // перемнная счётчик

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        savedInstanceState.putInt("countSave", count);

    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

    count = savedInstanceState.getInt( "countSave");
    textCount.setText(String.valueOf(count));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Присваивание переменным активити элементов представления
        textCount = findViewById(R.id.textView);
        button = findViewById(R.id.button);


        // Выполнение действия при нажатии кнопки
        button.setOnClickListener(listener);
    }

    //объект обработки нажатия кнопки (слушатель)
    private View.OnClickListener listener= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            count++;
            textCount.setText(String.valueOf(count));
        }
    };

    @Override
    protected void onStart()
    {super.onStart();

        // разещаем тост (контекст, сообщеие, длительность сообщения)
        Toast toast = Toast.makeText(this, "Cтарт активности", Toast.LENGTH_SHORT); // инициализация
        toast.setGravity(Gravity.LEFT, 0, 0); //задание позиции на экран ( положение, смещение по оси X, смещение по оси Y)
        toast.show(); // демонстрация тоста на экране
      //  System.out.println("Был указан метод onStart");
    }

    @Override
    protected void onPause(){
        super.onPause();


        // разещаем тост (контекст, сообщеие, длительность сообщения)
        Toast toast = Toast.makeText(this, "Пауза активности", Toast.LENGTH_SHORT); // инициализация
        toast.setGravity(Gravity.CENTER, 0, 0); //задание позиции на экран ( положение, смещение по оси X, смещение по оси Y)
        toast.show(); // демонстрация тоста на экране

     //  System.out.println("Был указан метод onPause");
    }

    @Override
    protected void onResume(){
        super.onResume();

        // разещаем тост (контекст, сообщеие, длительность сообщения)
        Toast toast = Toast.makeText(this, "Передача пользователю активности", Toast.LENGTH_SHORT); // инициализация


        // Добавление в тост картинки
        ImageView cat = new ImageView( this); // Создание объекта картинки (контекст)
        cat.setImageResource(R.drawable.cat); // Добавление картинки из ресурса

        
        // Помещение тоста в контейнер
        LinearLayout toastContainer = (LinearLayout) toast.getView();

    }

    @Override
    protected void onStop() {
        super.onStop();


        // разещаем тост (контекст, сообщеие, длительность сообщения)
        Toast toast = Toast.makeText(this, "Стоп активности", Toast.LENGTH_SHORT); // инициализация
        toast.show(); // демонстрация тоста на экране

     //   System.out.println("Был указан метод onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // разещаем тост (контекст, сообщеие, длительность сообщения)
        Toast toast = Toast.makeText(this, "Удаление активности", Toast.LENGTH_SHORT); // инициализация
        toast.show(); // демонстрация тоста на экране

     //   System.out.println("Был указан метод onDestroy");
    }
}