# homework_3_4![e79024f6-d4f8-4e6c-a9ec-f19ee9c73efe](https://user-images.githubusercontent.com/118921019/227654094-471bbf9a-98f4-41db-8260-b7a83bb0b682.jpg)
